#
# This is the server logic of a Shiny web application. You can run the 
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
   
  output$distPlot <- renderPlot({
    
    library(readxl)
    library(rpart)
    library(rpart.plot)
    german_credit <- read_excel("german credit card.xls") 
    my_replace <- replace(german_credit$purpose, "", "x")
    my_new_var <- gsub("X", "", german_credit$purpose)
    replace(german_credit$age ,which(german_credit$purpose=="X" & german_credit$duration > 2),"100")
    german_credit$good_bad <- gsub("bad", "0", german_credit$good_bad)
    german_credit$good_bad <- gsub("good", "1", german_credit$good_bad)
    german_credit$good_bad  <- as.numeric(german_credit$good_bad)
    
    replace(german_credit$age ,which(german_credit$purpose=="X" & german_credit$duration > 2),"100")
    
    my_ger_tree <- rpart(good_bad~age+coapp+duration, data=german_credit, method="class", cp=input$cp)
    rpart.plot(my_ger_tree, type=1, extra=1)
    
  })#do not remove these two
  
})
